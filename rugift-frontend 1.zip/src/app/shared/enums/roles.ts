export enum Roles {
  admin = 'Admin',
  customer = 'Customer',
}
