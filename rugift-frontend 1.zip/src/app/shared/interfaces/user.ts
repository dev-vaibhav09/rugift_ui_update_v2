interface Wallet {
  name: string;
  balance: number;
}

export interface User {
  id : string;
  mobile_no : string;
  firstname :string;
  lastname : string;
  email : string;
  token : string;
  role: string;
}
