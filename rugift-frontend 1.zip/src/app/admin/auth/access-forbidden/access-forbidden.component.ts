import { Component } from '@angular/core';

@Component({
  selector: 'app-access-forbidden',
  standalone: true,
  imports: [],
  templateUrl: './access-forbidden.component.html',
  styleUrl: './access-forbidden.component.scss'
})
export class AccessForbiddenComponent {

}
