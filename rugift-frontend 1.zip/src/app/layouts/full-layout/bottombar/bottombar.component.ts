import { Component } from '@angular/core';

@Component({
  selector: 'app-bottombar',
  standalone: true,
  imports: [],
  templateUrl: './bottombar.component.html',
  styleUrl: './bottombar.component.scss'
})
export class BottombarComponent {
  year: number = new Date().getFullYear();


}
