import {Component, Input, OnInit} from '@angular/core';
import {Router, RouterLink} from "@angular/router";
import {NgClass, NgForOf, NgIf, NgSwitch, NgSwitchCase, NgSwitchDefault} from "@angular/common";
import {ApiService} from "../../../shared/services/api.service";

interface Category {
  id: string;
  name: string;
  icon: string;
  route: string;
}

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  standalone: true,
  imports: [
    RouterLink,
    NgSwitch,
    NgSwitchCase,
    NgSwitchDefault,
    NgForOf,
    NgIf,
    NgClass
  ],
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit{
  error_message = '';
  @Input() card_title: string = "Explore";
  category_list: string[] = []
  constructor(
    private router: Router,
    private apiService : ApiService,
  ) { }

  ngOnInit(): void {
    this.apiService.get('vd/get_categories_list').subscribe({
      next: (res) => {
        console.log()
        this.category_list = res.data;
      },
      error: (error) => {
        this.error_message = error.error.error;
      },
    });
  }

  formatName(name: string): string {
    return name
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  }


  router_link(item: string) {
    this.router.navigate(['/vouchers',item]);
  }
}
