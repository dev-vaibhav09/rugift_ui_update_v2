import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-support',
  standalone: true,
  imports: [],
  templateUrl: './customer-support.component.html',
  styleUrl: './customer-support.component.scss'
})
export class CustomerSupportComponent {

}
