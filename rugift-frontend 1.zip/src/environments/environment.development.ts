export const environment = {
  production: true,
  // api_url: 'https://api.rugift.in/api/v1/',
  api_url: 'http://127.0.0.1:5000/api/v1/',

  APPX_INTERNAL_ACCESS_KEY_CODE: 'uxoXz2ToMuBjx_uB829lf7hikGtovnE-6yaoIOmesD0=',
  APPX_SESSION_KEY: '6541265432fghf132bc4hr321bn',
  APPX_AES_KEY: "1234567890abcdef1234567890abcdef",
  APPX_AES_IV: "abcdef1234567890",
  APP_PUBLIC_KEY: `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAr2funFG1MWNDxDv+AyyJ
/XqSZAXtznNo95Ars/7vgHwq+E114a7zzFSgfC9lxmEFSHvfqfqdq/2lRlbDcPE0
uNAgA0sy2kSx8YYbhwRS0IfGu+SApHZ/vrYf0b27s64dIj/sg6VdOCadDcJ684dt
GA9KPMpXMYUp0tYtsjhmZ7BzGQxxTLLahVC0X2XgdSJx6+Yvz7Pjey6PorJYGhHF
7c2JentPBn2fyPbDUQtGyPQat7DsJQ0bIW+3D0L3k3i4lEsVgaBzf4aRRoQAZG6s
DQj+oS0Kjjtc3l3IZcB1hpfl+I6T0uR17I/dxAoK/SnKd45TkH2rQu1Cs/kauJxh
KwIDAQAB
-----END PUBLIC KEY-----
`

};
